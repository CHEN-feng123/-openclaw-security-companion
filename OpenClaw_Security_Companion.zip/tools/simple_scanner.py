#!/usr/bin/env python3
"""
简单敏感文件扫描
"""

import os
import re
import json

def scan_for_sensitive():
    print("扫描敏感信息...")
    
    workspace = "C:\\Users\\zhouz\\.openclaw\\workspace"
    sensitive_files = []
    
    # 简单扫描前20个文件
    count = 0
    for root, dirs, files in os.walk(workspace):
        for file in files:
            if file.endswith(('.py', '.json', '.md')):
                filepath = os.path.join(root, file)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # 检查node_secret
                    if 'node_secret' in content:
                        # 提取node_secret值
                        matches = re.findall(r'node_secret\s*[:=]\s*[\'"]([^\'"]+)[\'"]', content)
                        if matches:
                            relative = os.path.relpath(filepath, workspace)
                            sensitive_files.append({
                                'file': relative,
                                'type': 'node_secret',
                                'count': len(matches)
                            })
                    
                    # 检查其他敏感信息
                    patterns = [
                        ('api_key', r'api[_-]?key\s*[:=]\s*[\'"]([^\'"]+)[\'"]'),
                        ('token', r'token\s*[:=]\s*[\'"]([^\'"]+)[\'"]'),
                        ('password', r'password\s*[:=]\s*[\'"]([^\'"]+)[\'"]')
                    ]
                    
                    for pattern_name, pattern in patterns:
                        matches = re.findall(pattern, content, re.IGNORECASE)
                        if matches:
                            relative = os.path.relpath(filepath, workspace)
                            sensitive_files.append({
                                'file': relative,
                                'type': pattern_name,
                                'count': len(matches)
                            })
                
                except:
                    pass
                
                count += 1
                if count >= 50:  # 只扫描50个文件
                    break
        
        if count >= 50:
            break
    
    print(f"\n扫描完成，检查了 {count} 个文件")
    print(f"发现 {len(sensitive_files)} 个文件包含敏感信息")
    
    if sensitive_files:
        print("\n发现的问题:")
        for item in sensitive_files[:10]:  # 只显示前10个
            print(f"  - {item['file']}: {item['type']} x{item['count']}")
        
        # 保存结果
        with open('sensitive_scan_results.json', 'w', encoding='utf-8') as f:
            json.dump({
                'scan_time': '2026-03-20',
                'files_scanned': count,
                'sensitive_files_found': len(sensitive_files),
                'details': sensitive_files
            }, f, indent=2, ensure_ascii=False)
        
        print(f"\n详细结果已保存到: sensitive_scan_results.json")
        
        print("\n建议:")
        print("1. 将node_secret等敏感信息移到环境变量")
        print("2. 创建.env文件存储敏感配置")
        print("3. 将.env添加到.gitignore")
        print("4. 提供.env.example模板")
    
    return len(sensitive_files)

if __name__ == "__main__":
    scan_for_sensitive()