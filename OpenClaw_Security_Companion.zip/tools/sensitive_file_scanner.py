#!/usr/bin/env python3
"""
敏感文件扫描与修复工具
"""

import os
import re
import json
from datetime import datetime

class SensitiveFileScanner:
    def __init__(self, workspace_path="."):
        self.workspace_path = workspace_path
        self.sensitive_patterns = {
            "api_key": r'(api[_-]?key|apikey)\s*[:=]\s*[\'"]([^\'"]+)[\'"]',
            "token": r'(token|access_token|refresh_token)\s*[:=]\s*[\'"]([^\'"]+)[\'"]',
            "secret": r'(secret|client_secret|private_key)\s*[:=]\s*[\'"]([^\'"]+)[\'"]',
            "password": r'(password|passwd|pwd)\s*[:=]\s*[\'"]([^\'"]+)[\'"]',
            "credential": r'(credential|auth|authentication)\s*[:=]\s*[\'"]([^\'"]+)[\'"]',
            "node_secret": r'(node_secret|node_secret_key)\s*[:=]\s*[\'"]([^\'"]+)[\'"]',
            "bearer_token": r'Bearer\s+([a-zA-Z0-9._-]+)',
        }
        
        self.sensitive_files = []
        self.found_issues = []
        
    def scan_file(self, filepath):
        """扫描单个文件"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                
            issues = []
            for pattern_name, pattern in self.sensitive_patterns.items():
                matches = re.findall(pattern, content, re.IGNORECASE)
                if matches:
                    for match in matches:
                        if isinstance(match, tuple):
                            # 提取实际的值
                            value = match[1] if len(match) > 1 else match[0]
                        else:
                            value = match
                        
                        # 屏蔽部分值用于显示
                        if len(value) > 8:
                            masked_value = value[:4] + "***" + value[-4:]
                        else:
                            masked_value = "***"
                        
                        issues.append({
                            "type": pattern_name,
                            "value": masked_value,
                            "full_match": str(match)[:50]
                        })
            
            if issues:
                relative_path = os.path.relpath(filepath, self.workspace_path)
                self.sensitive_files.append({
                    "file": relative_path,
                    "issues": issues,
                    "size": os.path.getsize(filepath)
                })
                
                return True
                
        except UnicodeDecodeError:
            # 跳过二进制文件
            pass
        except Exception as e:
            print(f"扫描文件 {filepath} 时出错: {e}")
            
        return False
    
    def scan_workspace(self):
        """扫描整个工作空间"""
        print("开始扫描工作空间中的敏感信息...")
        print(f"工作空间路径: {self.workspace_path}")
        print("-" * 60)
        
        scanned_count = 0
        sensitive_count = 0
        
        for root, dirs, files in os.walk(self.workspace_path):
            # 跳过一些目录
            skip_dirs = ['.git', 'node_modules', '__pycache__', '.clawhub']
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            
            for file in files:
                # 只扫描文本文件
                if file.endswith(('.py', '.md', '.json', '.txt', '.yaml', '.yml', '.js', '.ts')):
                    filepath = os.path.join(root, file)
                    scanned_count += 1
                    
                    if self.scan_file(filepath):
                        sensitive_count += 1
        
        print(f"扫描完成!")
        print(f"扫描文件数: {scanned_count}")
        print(f"发现敏感文件: {sensitive_count}")
        
        return self.sensitive_files
    
    def generate_report(self):
        """生成扫描报告"""
        if not self.sensitive_files:
            print("未发现包含敏感信息的文件")
            return
        
        print("\n" + "=" * 60)
        print("敏感文件扫描报告")
        print("=" * 60)
        
        total_issues = sum(len(f["issues"]) for f in self.sensitive_files)
        
        print(f"\n发现 {len(self.sensitive_files)} 个文件包含敏感信息:")
        print(f"总共 {total_issues} 个敏感信息项")
        
        for file_info in self.sensitive_files[:10]:  # 只显示前10个
            print(f"\n📄 文件: {file_info['file']}")
            print(f"   大小: {file_info['size']} 字节")
            print(f"   问题: {len(file_info['issues'])} 个")
            
            for issue in file_info['issues'][:3]:  # 只显示前3个问题
                print(f"     - {issue['type']}: {issue['value']}")
        
        if len(self.sensitive_files) > 10:
            print(f"\n... 还有 {len(self.sensitive_files) - 10} 个文件未显示")
        
        # 保存详细报告
        report_file = "sensitive_files_report.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump({
                "scan_time": datetime.now().isoformat(),
                "workspace": self.workspace_path,
                "total_files_scanned": len(self.sensitive_files),
                "total_issues": total_issues,
                "files": self.sensitive_files
            }, f, indent=2, ensure_ascii=False)
        
        print(f"\n详细报告已保存到: {report_file}")
    
    def suggest_fixes(self):
        """提供修复建议"""
        print("\n" + "=" * 60)
        print("修复建议")
        print("=" * 60)
        
        suggestions = [
            "1. 使用环境变量替代硬编码的密钥",
            "2. 将敏感配置移动到单独的配置文件",
            "3. 对配置文件进行加密",
            "4. 使用密钥管理服务",
            "5. 定期轮换密钥",
            "6. 实施访问控制",
            "7. 添加敏感信息检测到CI/CD流程",
            "8. 对开发人员进行安全培训"
        ]
        
        print("\n建议的修复措施:")
        for suggestion in suggestions:
            print(f"  {suggestion}")
        
        print("\n具体实施步骤:")
        print("  1. 创建 .env 文件存储环境变量")
        print("  2. 修改代码从环境变量读取配置")
        print("  3. 将 .env 文件添加到 .gitignore")
        print("  4. 提供 .env.example 模板文件")
        print("  5. 更新文档说明配置方法")
        
        # 创建修复脚本模板
        fix_template = """#!/usr/bin/env python3
"""
        
        fix_file = "fix_sensitive_files_template.py"
        with open(fix_file, 'w', encoding='utf-8') as f:
            f.write(fix_template)
        
        print(f"\n修复脚本模板已保存到: {fix_file}")

def main():
    print("OpenClaw敏感文件扫描工具")
    print("=" * 60)
    
    scanner = SensitiveFileScanner("C:\\Users\\zhouz\\.openclaw\\workspace")
    
    # 扫描工作空间
    sensitive_files = scanner.scan_workspace()
    
    if sensitive_files:
        # 生成报告
        scanner.generate_report()
        
        # 提供修复建议
        scanner.suggest_fixes()
        
        print("\n" + "=" * 60)
        print("重要提醒:")
        print("=" * 60)
        print("1. 请立即处理发现的敏感信息")
        print("2. 不要将包含敏感信息的文件提交到版本控制")
        print("3. 定期运行此扫描工具")
        print("4. 建立敏感信息管理流程")
        
        return 1  # 返回非零表示发现敏感信息
    else:
        print("\n✅ 未发现敏感信息，安全性良好!")
        return 0

if __name__ == "__main__":
    exit(main())