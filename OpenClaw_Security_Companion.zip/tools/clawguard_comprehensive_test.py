#!/usr/bin/env python3
"""
OpenClaw安全伴侣综合测试
"""

import os
import re
import json
import hashlib
from datetime import datetime

class ClawGuardTester:
    def __init__(self):
        self.test_results = []
        self.workspace_path = "C:\\Users\\zhouz\\.openclaw\\workspace"
        
    def log_test(self, test_name, status, details=""):
        """记录测试结果"""
        result = {
            "test_name": test_name,
            "status": status,
            "timestamp": datetime.now().isoformat(),
            "details": details
        }
        self.test_results.append(result)
        
        status_symbol = "[PASS]" if status == "pass" else "[FAIL]" if status == "fail" else "[WARN]"
        print(f"{status_symbol} {test_name}")
        if details:
            print(f"    详情: {details}")
    
    def test_workspace_security(self):
        """测试工作空间安全性"""
        print("\n1. 工作空间安全性测试")
        print("-" * 40)
        
        # 检查敏感文件
        sensitive_files = []
        for root, dirs, files in os.walk(self.workspace_path):
            for file in files:
                filepath = os.path.join(root, file)
                # 检查是否包含敏感信息
                if any(keyword in file.lower() for keyword in ['password', 'secret', 'key', 'token', 'credential']):
                    sensitive_files.append(filepath)
        
        if sensitive_files:
            self.log_test("敏感文件检查", "warn", f"发现可能包含敏感信息的文件: {len(sensitive_files)}个")
            for f in sensitive_files[:3]:  # 只显示前3个
                print(f"    - {os.path.basename(f)}")
        else:
            self.log_test("敏感文件检查", "pass", "未发现明显的敏感文件")
    
    def test_file_permissions(self):
        """测试文件权限"""
        print("\n2. 文件权限测试")
        print("-" * 40)
        
        # 检查关键文件的权限
        critical_files = [
            "MEMORY.md",
            "USER.md",
            "IDENTITY.md",
            "SOUL.md"
        ]
        
        permission_issues = []
        for file in critical_files:
            filepath = os.path.join(self.workspace_path, file)
            if os.path.exists(filepath):
                # 检查文件是否可被其他用户读取
                try:
                    # 在Windows上，检查文件属性
                    import stat
                    mode = os.stat(filepath).st_mode
                    if mode & stat.S_IROTH:  # 其他用户可读
                        permission_issues.append(f"{file}: 其他用户可读")
                except:
                    permission_issues.append(f"{file}: 权限检查失败")
        
        if permission_issues:
            self.log_test("文件权限检查", "warn", f"发现权限问题: {len(permission_issues)}个")
            for issue in permission_issues:
                print(f"    - {issue}")
        else:
            self.log_test("文件权限检查", "pass", "关键文件权限正常")
    
    def test_security_scripts(self):
        """测试安全脚本"""
        print("\n3. 安全脚本测试")
        print("-" * 40)
        
        security_scripts = [
            "capsule_security_check.py",
            "capsule_integrity_check.py"
        ]
        
        missing_scripts = []
        for script in security_scripts:
            script_path = os.path.join(self.workspace_path, script)
            if not os.path.exists(script_path):
                missing_scripts.append(script)
        
        if missing_scripts:
            self.log_test("安全脚本完整性", "fail", f"缺失安全脚本: {missing_scripts}")
        else:
            self.log_test("安全脚本完整性", "pass", "所有安全脚本都存在")
            
            # 测试脚本可执行性
            for script in security_scripts:
                try:
                    # 尝试导入模块
                    module_name = script.replace('.py', '')
                    __import__(module_name)
                    self.log_test(f"{script} 可导入", "pass")
                except Exception as e:
                    self.log_test(f"{script} 可导入", "fail", f"导入失败: {e}")
    
    def test_data_encryption(self):
        """测试数据加密"""
        print("\n4. 数据加密测试")
        print("-" * 40)
        
        # 检查是否有加密相关代码
        encryption_keywords = ['encrypt', 'decrypt', 'cipher', 'aes', 'rsa', 'sha256']
        
        python_files = []
        for root, dirs, files in os.walk(self.workspace_path):
            for file in files:
                if file.endswith('.py'):
                    python_files.append(os.path.join(root, file))
        
        encryption_found = False
        for py_file in python_files[:10]:  # 只检查前10个文件
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    if any(keyword in content.lower() for keyword in encryption_keywords):
                        encryption_found = True
                        break
            except:
                continue
        
        if encryption_found:
            self.log_test("加密功能检查", "pass", "发现加密相关代码")
        else:
            self.log_test("加密功能检查", "warn", "未发现明显的加密实现")
    
    def test_external_connections(self):
        """测试外部连接安全性"""
        print("\n5. 外部连接测试")
        print("-" * 40)
        
        # 检查API端点安全性
        api_endpoints = []
        python_files = []
        
        for root, dirs, files in os.walk(self.workspace_path):
            for file in files:
                if file.endswith('.py'):
                    python_files.append(os.path.join(root, file))
        
        for py_file in python_files[:5]:  # 只检查前5个文件
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # 查找URL
                    urls = re.findall(r'https?://[^\s<>"\']+', content)
                    api_endpoints.extend(urls)
            except:
                continue
        
        secure_endpoints = []
        insecure_endpoints = []
        
        for url in api_endpoints:
            if url.startswith('https://'):
                secure_endpoints.append(url)
            else:
                insecure_endpoints.append(url)
        
        if insecure_endpoints:
            self.log_test("API端点安全性", "fail", f"发现不安全的HTTP连接: {len(insecure_endpoints)}个")
            for url in insecure_endpoints[:3]:
                print(f"    - {url}")
        else:
            self.log_test("API端点安全性", "pass", f"所有API端点使用HTTPS: {len(secure_endpoints)}个")
    
    def test_memory_protection(self):
        """测试内存保护"""
        print("\n6. 内存保护测试")
        print("-" * 40)
        
        # 检查MEMORY.md文件的安全性
        memory_file = os.path.join(self.workspace_path, "MEMORY.md")
        
        if os.path.exists(memory_file):
            try:
                with open(memory_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                    # 检查是否包含敏感信息
                    sensitive_patterns = [
                        r'password\s*[:=]\s*\S+',
                        r'secret\s*[:=]\s*\S+',
                        r'token\s*[:=]\s*\S+',
                        r'key\s*[:=]\s*\S+'
                    ]
                    
                    sensitive_found = False
                    for pattern in sensitive_patterns:
                        if re.search(pattern, content, re.IGNORECASE):
                            sensitive_found = True
                            break
                    
                    if sensitive_found:
                        self.log_test("内存文件安全性", "fail", "MEMORY.md中包含敏感信息")
                    else:
                        self.log_test("内存文件安全性", "pass", "MEMORY.md中未发现敏感信息")
                        
                    # 检查文件大小
                    file_size = os.path.getsize(memory_file)
                    if file_size > 100000:  # 大于100KB
                        self.log_test("内存文件大小", "warn", f"MEMORY.md文件较大: {file_size}字节")
                    else:
                        self.log_test("内存文件大小", "pass", f"MEMORY.md文件大小正常: {file_size}字节")
                        
            except Exception as e:
                self.log_test("内存文件访问", "fail", f"无法访问MEMORY.md: {e}")
        else:
            self.log_test("内存文件存在性", "warn", "MEMORY.md文件不存在")
    
    def generate_report(self):
        """生成测试报告"""
        print("\n" + "=" * 60)
        print("OpenClaw安全伴侣综合测试报告")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for r in self.test_results if r['status'] == 'pass')
        failed_tests = sum(1 for r in self.test_results if r['status'] == 'fail')
        warning_tests = sum(1 for r in self.test_results if r['status'] == 'warn')
        
        print(f"\n测试统计:")
        print(f"  总测试数: {total_tests}")
        print(f"  通过: {passed_tests}")
        print(f"  失败: {failed_tests}")
        print(f"  警告: {warning_tests}")
        
        print(f"\n通过率: {passed_tests/total_tests*100:.1f}%")
        
        print("\n详细结果:")
        for result in self.test_results:
            status_symbol = "[PASS]" if result['status'] == 'pass' else "[FAIL]" if result['status'] == 'fail' else "[WARN]"
            print(f"  {status_symbol} {result['test_name']}")
            if result['details']:
                print(f"      {result['details']}")
        
        print("\n" + "=" * 60)
        print("改进建议:")
        print("=" * 60)
        
        # 基于测试结果生成建议
        suggestions = []
        
        if failed_tests > 0:
            suggestions.append("1. 立即修复失败的测试项")
        
        if warning_tests > 0:
            suggestions.append("2. 审查警告项，决定是否需要修复")
        
        if passed_tests/total_tests < 0.8:
            suggestions.append("3. 整体安全水平需要提升")
        
        suggestions.append("4. 定期运行安全测试")
        suggestions.append("5. 建立安全审计日志")
        suggestions.append("6. 实施数据加密策略")
        
        for i, suggestion in enumerate(suggestions, 1):
            print(f"{i}. {suggestion}")
        
        # 保存报告
        report_file = "clawguard_security_test_report.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump({
                "timestamp": datetime.now().isoformat(),
                "summary": {
                    "total_tests": total_tests,
                    "passed": passed_tests,
                    "failed": failed_tests,
                    "warnings": warning_tests,
                    "pass_rate": passed_tests/total_tests*100
                },
                "results": self.test_results,
                "suggestions": suggestions
            }, f, indent=2, ensure_ascii=False)
        
        print(f"\n详细报告已保存到: {report_file}")
        
        return passed_tests == total_tests  # 所有测试都通过才算成功

def main():
    print("=" * 60)
    print("OpenClaw安全伴侣综合测试")
    print("=" * 60)
    
    tester = ClawGuardTester()
    
    # 运行所有测试
    tester.test_workspace_security()
    tester.test_file_permissions()
    tester.test_security_scripts()
    tester.test_data_encryption()
    tester.test_external_connections()
    tester.test_memory_protection()
    
    # 生成报告
    all_passed = tester.generate_report()
    
    if all_passed:
        print("\n[SUCCESS] 所有安全测试通过!")
        return 0
    else:
        print("\n[WARNING] 安全测试发现需要改进的问题")
        return 1

if __name__ == "__main__":
    exit(main())