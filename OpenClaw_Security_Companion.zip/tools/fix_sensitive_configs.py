#!/usr/bin/env python3
"""
修复敏感配置脚本
"""

import os
import re

def create_env_file():
    """创建.env文件"""
    env_content = """# OpenClaw环境变量配置

# EvoMap节点配置
EVOMAP_NODE_ID=node_b1057111e2821868
EVOMAP_NODE_SECRET=132469a2cb48cbfbc967619ea9c651a76d8160b0ca2c4e484e0e22a234f5204d

# 注意：实际使用时应该从环境变量读取
# 例如：node_secret = os.getenv('EVOMAP_NODE_SECRET')
"""
    
    with open('.env', 'w', encoding='utf-8') as f:
        f.write(env_content)
    
    print("已创建 .env 文件")
    print("请确保将 .env 添加到 .gitignore")

def update_python_files():
    """更新Python文件使用环境变量"""
    files_to_update = [
        "complete_task_submission.py",
        "check_evomap_tasks.py",
        "check_specific_task.py",
        "check_tasks_simple.py",
        "evomap_auto_claim.py",
        "evomap_auto_login.py"
    ]
    
    updates_made = 0
    
    for filename in files_to_update:
        if not os.path.exists(filename):
            continue
            
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 替换硬编码的node_secret
            old_content = content
            
            # 替换NODE_SECRET
            content = re.sub(
                r'NODE_SECRET\s*=\s*["\'][^"\']+["\']',
                'NODE_SECRET = os.getenv("EVOMAP_NODE_SECRET", "")',
                content
            )
            
            # 替换node_secret变量
            content = re.sub(
                r'node_secret\s*=\s*["\'][^"\']+["\']',
                'node_secret = os.getenv("EVOMAP_NODE_SECRET", "")',
                content
            )
            
            # 添加import os如果不存在
            if 'import os' not in content and 'from os import' not in content:
                # 在文件开头添加import
                lines = content.split('\n')
                import_added = False
                for i, line in enumerate(lines):
                    if line.strip().startswith('import ') or line.strip().startswith('from '):
                        lines.insert(i, 'import os')
                        import_added = True
                        break
                
                if not import_added:
                    lines.insert(0, 'import os')
                
                content = '\n'.join(lines)
            
            if content != old_content:
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                print(f"已更新: {filename}")
                updates_made += 1
            else:
                print(f"无需更新: {filename}")
                
        except Exception as e:
            print(f"更新 {filename} 时出错: {e}")
    
    return updates_made

def create_gitignore():
    """创建.gitignore文件"""
    gitignore_content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Environment
.env
.env.local
.env.*.local

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
logs/
*.log

# Test
.coverage
htmlcov/
.pytest_cache/

# OpenClaw specific
memory/raw/
*.session
*.tmp
"""
    
    with open('.gitignore', 'w', encoding='utf-8') as f:
        f.write(gitignore_content)
    
    print("已创建 .gitignore 文件")

def create_security_readme():
    """创建安全说明文档"""
    readme_content = """# OpenClaw安全配置指南

## 环境变量配置

### 1. 配置环境变量
1. 复制 `.env.example` 为 `.env`
2. 在 `.env` 中填写实际值
3. 确保 `.env` 不被提交到版本控制

### 2. 使用环境变量
在Python代码中：
```python
import os

node_id = os.getenv('EVOMAP_NODE_ID')
node_secret = os.getenv('EVOMAP_NODE_SECRET')

if not node_secret:
    raise ValueError("请设置EVOMAP_NODE_SECRET环境变量")
```

### 3. 安全最佳实践
1. **不要硬编码敏感信息**
2. **使用环境变量或密钥管理服务**
3. **定期轮换密钥**
4. **实施访问控制**
5. **记录安全事件**

## 文件权限设置

### Windows
```cmd
icacls MEMORY.md /deny "Everyone:(R)"
icacls USER.md /deny "Everyone:(R)"
icacls IDENTITY.md /deny "Everyone:(R)"
icacls SOUL.md /deny "Everyone:(R)"
```

### Linux/Mac
```bash
chmod 600 MEMORY.md USER.md IDENTITY.md SOUL.md
```

## 定期安全检查

### 1. 运行安全测试
```bash
python clawguard_comprehensive_test.py
```

### 2. 扫描敏感信息
```bash
python sensitive_file_scanner.py
```

### 3. 检查文件权限
```bash
python -c "import os; print('文件权限检查...')"
```

## 应急响应

### 发现敏感信息泄露
1. 立即轮换所有相关密钥
2. 审查日志，确定泄露范围
3. 通知相关方
4. 实施额外安全措施

### 联系方式
- 安全负责人: [填写负责人]
- 应急邮箱: [填写邮箱]
- 联系电话: [填写电话]

---
*最后更新: 2026-03-20*
"""
    
    with open('SECURITY_README.md', 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print("已创建 SECURITY_README.md")

def main():
    print("=" * 60)
    print("OpenClaw敏感配置修复工具")
    print("=" * 60)
    
    print("\n1. 创建环境配置文件...")
    create_env_file()
    
    print("\n2. 更新Python文件使用环境变量...")
    updates = update_python_files()
    print(f"   更新了 {updates} 个文件")
    
    print("\n3. 创建.gitignore文件...")
    create_gitignore()
    
    print("\n4. 创建安全说明文档...")
    create_security_readme()
    
    print("\n" + "=" * 60)
    print("修复完成!")
    print("=" * 60)
    
    print("\n下一步:")
    print("1. 检查 .env 文件中的配置是否正确")
    print("2. 测试更新后的脚本是否正常工作")
    print("3. 将 .env 添加到 .gitignore (已自动添加)")
    print("4. 定期运行安全测试")
    
    print("\n重要提醒:")
    print("✅ 敏感信息已从代码中移除")
    print("✅ 使用环境变量管理配置")
    print("✅ 创建了安全文档")
    print("⚠️  请确保 .env 文件的安全")
    
    return 0

if __name__ == "__main__":
    exit(main())