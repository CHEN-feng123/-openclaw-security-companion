#!/usr/bin/env python3
"""
Capsule安全性检查
"""

import re
import json
from datetime import datetime

class CapsuleSecurityChecker:
    def __init__(self, filepath):
        self.filepath = filepath
        with open(filepath, 'r', encoding='utf-8') as f:
            self.content = f.read()
        
        self.issues = []
        self.warnings = []
        
    def check_sensitive_info(self):
        """检查敏感信息"""
        print("检查敏感信息...")
        
        # 邮箱模式
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        emails = re.findall(email_pattern, self.content)
        if emails:
            self.issues.append(f"发现邮箱地址: {emails}")
        
        # 密码模式（简单检测）
        password_keywords = ['password', 'passwd', 'pwd', 'secret', 'token', 'key']
        for keyword in password_keywords:
            if re.search(rf'\b{keyword}\s*[:=]\s*\S+', self.content, re.IGNORECASE):
                self.warnings.append(f"可能包含密码相关关键词: {keyword}")
        
        # IP地址
        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        ips = re.findall(ip_pattern, self.content)
        if ips:
            self.warnings.append(f"发现IP地址: {ips}")
        
        return len(self.issues) == 0
    
    def check_external_links(self):
        """检查外部链接"""
        print("检查外部链接...")
        
        url_pattern = r'https?://[^\s<>"\']+'
        urls = re.findall(url_pattern, self.content)
        
        safe_domains = ['evomap.ai', 'mit.edu', 'stanford.edu', 'cambridge.org', 'arxiv.org']
        external_urls = []
        
        for url in urls:
            is_safe = any(domain in url for domain in safe_domains)
            if not is_safe:
                external_urls.append(url)
        
        if external_urls:
            self.warnings.append(f"发现外部链接: {external_urls}")
        
        return True
    
    def check_code_safety(self):
        """检查代码安全性"""
        print("检查代码安全性...")
        
        dangerous_patterns = [
            (r'eval\s*\(', 'eval函数调用'),
            (r'exec\s*\(', 'exec函数调用'),
            (r'subprocess\.', '子进程调用'),
            (r'os\.system', '系统命令执行'),
            (r'__import__', '动态导入'),
        ]
        
        for pattern, description in dangerous_patterns:
            if re.search(pattern, self.content):
                self.issues.append(f"发现潜在危险代码: {description}")
        
        return len(self.issues) == 0
    
    def check_content_compliance(self):
        """检查内容合规性"""
        print("检查内容合规性...")
        
        compliance_issues = []
        
        # 检查是否有攻击性内容
        offensive_terms = ['hack', 'exploit', 'bypass', 'crack']
        for term in offensive_terms:
            if re.search(rf'\b{term}\b', self.content, re.IGNORECASE):
                compliance_issues.append(f"可能包含敏感术语: {term}")
        
        # 检查是否有不当引用
        if compliance_issues:
            self.warnings.extend(compliance_issues)
        
        return True
    
    def run_all_checks(self):
        """运行所有检查"""
        print("="*60)
        print("Capsule安全性检查")
        print(f"文件: {self.filepath}")
        print(f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*60)
        
        checks = [
            ("敏感信息检查", self.check_sensitive_info),
            ("外部链接检查", self.check_external_links),
            ("代码安全性检查", self.check_code_safety),
            ("内容合规性检查", self.check_content_compliance),
        ]
        
        all_passed = True
        
        for check_name, check_func in checks:
            try:
                passed = check_func()
                status = "[PASS]" if passed else "[FAIL]"
                print(f"{check_name}: {status}")
                if not passed:
                    all_passed = False
            except Exception as e:
                print(f"{check_name}: [ERROR] 检查异常 - {e}")
                all_passed = False
        
        print("\n" + "="*60)
        print("检查结果汇总:")
        
        if self.issues:
            print("[CRITICAL] 发现严重问题:")
            for issue in self.issues:
                print(f"  - {issue}")
            all_passed = False
        
        if self.warnings:
            print("[WARNING] 发现警告:")
            for warning in self.warnings:
                print(f"  - {warning}")
        
        if all_passed and not self.issues:
            print("[SUCCESS] 所有安全检查通过")
        
        print("="*60)
        
        return all_passed

def main():
    checker = CapsuleSecurityChecker("capsule_human_ai_knowledge_encapsulation.md")
    passed = checker.run_all_checks()
    
    if passed:
        print("\n[SUCCESS] Capsule安全性检查通过，可以继续下一步")
        return 0
    else:
        print("\n[FAILURE] Capsule安全性检查失败，需要修复问题")
        return 1

if __name__ == "__main__":
    exit(main())